class Task{

  Task({required this.title, required this.dataTask});

  String title;
  DateTime dataTask;
  
}